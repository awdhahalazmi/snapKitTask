//
//  ViewController.swift
//  snapkit task
//
//  Created by Awdhah Alazemi on 27/02/2024.
//

import UIKit
import SnapKit

class ViewController: UIViewController {
    let profileImageView = UIImageView()
    let titleLabel = UILabel()
    let usernameLabel = UILabel()
    let bioLabel = UILabel()
    let check = UIImageView( )
    override func viewDidLoad() {
        view.addSubview(profileImageView)
        view.addSubview(usernameLabel)
        view.addSubview(titleLabel)
        view.addSubview(bioLabel)
        view.addSubview(check)

        
        super.viewDidLoad()
        view.backgroundColor = .black
        
        setUpUI()
        setUpConstrains()
        // Do any additional setup after loading the view.
    }

    func setUpUI( ){
        
        profileImageView.image = UIImage(named: "codedimage" )
        profileImageView.layer.cornerRadius = 37.5
        profileImageView.clipsToBounds = true
        
        check.image = UIImage(named: "check" )
        
        titleLabel.text = "Coded"
        titleLabel.textColor = .white
        titleLabel.font = UIFont.boldSystemFont(ofSize: 20.0)

        usernameLabel.text = "@joincoded "
        usernameLabel.textColor = .white
        usernameLabel.font = UIFont.boldSystemFont(ofSize: 15.0)
        
        bioLabel.text = "bio"
        bioLabel.textColor = .white
        bioLabel.text = "🥇 1st Coding Academy in the Middle East \n💡 learn to code websties and apps \n 📚 intensive courses and bootcamps"
        bioLabel.font = UIFont.boldSystemFont(ofSize: 13.0)
        bioLabel.numberOfLines = 5
            
    }
    
    
    func setUpConstrains( ){
        profileImageView.snp.makeConstraints { make in
                  make.centerX.equalToSuperview()
                  make.top.equalTo(view.safeAreaLayoutGuide.snp.top).offset(180)
                  make.height.width.equalTo(250)
              }
        
        profileImageView.snp.makeConstraints { make in
            make.top.equalTo( view.safeAreaLayoutGuide.snp.top).offset(10)
            make.right.equalToSuperview().offset(-15)
            make.height.width.equalTo(75)
        }
        
        check.snp.makeConstraints { make in
            make.top.equalTo( profileImageView.snp.top).offset(0)
            make.right.equalToSuperview().offset(-10)
            make.height.width.equalTo(25)
        }
        
     
        titleLabel.snp.makeConstraints { make in
             
            make.top.equalTo(profileImageView.snp.bottom).offset(20)
            make.leading.equalToSuperview().offset(20)
             
         }
        
        usernameLabel.snp.makeConstraints { make in
             
            make.top.equalTo(titleLabel.snp.bottom).offset(20)
            make.leading.equalToSuperview().offset(20)
             
         }
        
        bioLabel.snp.makeConstraints { make in
            make.top.equalTo(usernameLabel.snp.bottom).offset(10)
            make.leading.equalTo(usernameLabel.snp.leading)
        }
    }
}


#if canImport(SwiftUI) && DEBUG
import SwiftUI

// Change your Represenable name
struct CustomViewControllerRepresentable: UIViewControllerRepresentable {
    
    typealias UIViewControllerType = ViewController // Change ViewController to YourViewController
    
    func makeUIViewController(context: Context) -> ViewController { // Change ViewController to YourViewController
        
        
        ViewController() // Change YourViewController to your desired view controller
        
    }
    
    func updateUIViewController(_ uiViewController: ViewController, context: Context) { // Change ViewController to YourViewController
        
    }
}

struct NameViewController_Preview: PreviewProvider {
    static var previews: some View {
        
        // Change the representable
        CustomViewControllerRepresentable()
    }
}
#endif


